//
//  ViewControllerB.h
//  passValueViaObj
//
//  Created by jianfeng on 15/1/30.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"

@interface ViewControllerB : UIViewController

//@property (nonatomic, strong) NSDictionary *studentDic;

@property (nonatomic, strong) Student *sss;

@end
