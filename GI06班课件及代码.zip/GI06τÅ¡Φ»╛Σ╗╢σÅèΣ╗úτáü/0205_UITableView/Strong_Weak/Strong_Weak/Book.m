//
//  Book.m
//  Strong_Weak
//
//  Created by jianfeng on 15/2/5.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import "Book.h"

@class Student;

@implementation Book

- (void)dealloc
{
    NSLog(@"Book被销毁了");
}

@end
