//
//  Student.m
//  StrongAndWeak
//
//  Created by jianfeng on 15/2/5.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import "Student.h"

@implementation Student

- (void)dealloc
{
    NSLog(@"Student被销毁了");
}

@end
