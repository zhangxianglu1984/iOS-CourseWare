//
//  PersonCell.h
//  UITableViewCell
//
//  Created by jianfeng on 15/2/5.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"

@interface PersonCell : UITableViewCell

@property (nonatomic, strong) Person *person;

@end
