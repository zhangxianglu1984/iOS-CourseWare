//
//  AppDelegate.h
//  CustomCell_xib
//
//  Created by jianfeng on 15/2/9.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

