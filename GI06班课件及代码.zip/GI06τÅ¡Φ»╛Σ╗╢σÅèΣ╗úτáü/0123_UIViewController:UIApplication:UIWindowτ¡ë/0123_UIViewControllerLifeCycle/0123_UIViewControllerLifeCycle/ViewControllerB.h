//
//  ViewControllerB.h
//  0123_UIViewControllerLifeCycle
//
//  Created by jianfeng on 15/1/23.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerB : UIViewController

@end
