//
//  Defines.h
//  UIPickerView
//
//  Created by jianfeng on 15/2/11.
//  Copyright (c) 2015年 test. All rights reserved.
//

#ifndef UIPickerView_Defines_h
#define UIPickerView_Defines_h

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#endif
