//
//  ViewController.h
//  0123_UIViewControllerLifeCycle
//
//  Created by jianfeng on 15/1/23.
//  Copyright (c) 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)clickButton:(UIButton *)sender;

@end

